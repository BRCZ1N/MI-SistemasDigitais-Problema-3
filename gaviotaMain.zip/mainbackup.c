#include "prototype.h"
pthread_mutex_t lockStates;
int stateGame, buttons, buttonValue = 15, currentOption = 0;

/*
 * Função principal que inicializa o ambiente do jogo Tetris.
 * Cria duas threads:
 * - A primeira thread executa a função execAccel, que lida com a função principal de execução do acelerômetro.
 * - A segunda thread executa a função execTetris, que contém a lógica principal do jogo Tetris.
 * Um mutex é inicializado para garantir que o acesso a recursos compartilhados, como a variável axis_x, seja feito de maneira segura.
 * As threads são unidas ao final da execução, garantindo que o programa aguarde a conclusão de ambas antes de encerrar.
 */
int main()
{
    pthread_t thread1, thread2, thread3, thread4;

    pthread_mutex_init(&lock, NULL);
    pthread_mutex_init(&lockMouse, NULL);
    pthread_mutex_init(&lockStates, NULL);

    pthread_create(&thread1, NULL, execAccel, NULL);
    pthread_create(&thread2, NULL, execPong, NULL);
    pthread_create(&thread3, NULL, execMouse, NULL);
    pthread_create(&thread4, NULL, changeStateExec, NULL);

    pthread_join(thread1, NULL);
    pthread_join(thread2, NULL);
    pthread_join(thread3, NULL);
    pthread_join(thread4, NULL);

    pthread_mutex_destroy(&lock);
    pthread_mutex_destroy(&lockMouse);
    pthread_mutex_destroy(&lockStates);

    return 0;
}
/**
 * Função principal do jogo Tetris que controla a lógica do jogo.
 *
 * Esta função é executada em uma thread separada e gerencia o fluxo
 * do jogo Tetris, incluindo a inicialização do tabuleiro, controle
 * dos tetrominos, verificação de condições de jogo, e exibição
 * do estado do jogo na tela. O loop principal continua até que o
 * jogo esteja terminado, e ele permite alternar entre pausar e
 * retomar o jogo.
 *
 * @note A função utiliza variáveis globais para o controle do estado
 *       do jogo e acesso a recursos de vídeo.
 */
// void execTetris()
// {

//     int16_t mg_per_lsb = 4;
//
int checkEndGame(int scoreJ1, int scoreJ2)
{
    if (scoreJ1 == 3)
    {

        return 1;
    }
    else if (scoreJ2 == 3)
    {

        return 0;
    }
    else
    {

        return -1;
    }
}


int normalizeValue(int value, int scale_factor)
{
    const int thresholds[] = {400, 200, 100, 50, 25};
    const int normalized[] = {8, 6, 4, 2, 1};

    // Escala o valor para ajustar a magnitude
    value = value / scale_factor;

    for (int i = 0; i < 5; i++)
    {
        if (value >= thresholds[i])
        {
            return normalized[i];
        }
        else if (value <= -thresholds[i])
        {
            return -normalized[i];
        }
    }
}

// Mover para perto do video clear
void clearSprite()
{
    for (int i = 0; i < 32; i++)
    {

        setSprite(i, 0, 0, 0, 0);
    }
}

int execPong()
{
    gpuMapping();
    changeSprite(5, seagull_data[0]);
    changeSprite(6, seagull_data);
    changeSprite(7, seagull_data[0]);
    changeSprite(8, seagull_data[1]);


    int16_t mg_per_lsb = 4;
    int flagGameOver = -1, velX = 1, velXMouse = 1, cima = 1, direita = 1, movVertical = 1, vert = 1, hori = 1;
    // buttons = buttonRead();

    /* Inicializar os elementos do jogo */
    int scoreJ1, scoreJ2;
    Ball ball;
    Bar barJ1;
    Bar barJ2;

    /*Loop principal do jogo*/
    while (1)
    {
        /*Posiciona elementos e iniciar a maquina de estado da tela*/
        stateGame = 0;
        scoreJ1 = 0;
        scoreJ2 = 0;
        resetData(&ball, &barJ1, &barJ2);

        /*Loop da patida do jogo*/
        while (1)
        { // Enquanto o jogador não perdeu e não ganhou o jogo

            // buttons = buttonRead();

            // if (buttons != 15)
            // {

            //     buttonValue = buttons;
            // }

            // changeState(&stateGame, &buttonValue, buttons);

            /* switch para mudar a tela de acordo com o estado */
            if (stateGame == 0)
            { // Tela inicial
                videoClear();
                clearSprite();
                Fhome();
                // while (stateGame == 0){

                //     Fhome();

                //     //Fazer thread para essa merda aq
                //     buttons = buttonRead();

                //     if(buttons != 15){

                //         buttonValue = buttons;

                //     }
                //     changeState(&stateGame, &buttonValue, buttons);

                // }

                /*Desenhar elementos do jogo*/
                resetData(&ball, &barJ1, &barJ2);
                // screenMenu();
            }
            else if (stateGame == 1)
            { // Tela do jogo

                videoClearSet(11, 2, 70, 58);
                // generateBall(ball.ballPositionX, ball.ballPositionY, COLOR_WHITE);
                
               


                while (1)
                {
                    if (isFull() == 0)
                    {   // registrador, sprite, offset, x, y
                        // setSprite(1, 1, 1, 280, 200);
                        // setSprite(2, 2, 1, 260, 200);
                        // setSprite(3, 3, 1, 240, 200);
                        // setSprite(4, 4, 1, 220, 200);
                        // setSprite(5, 5, 1, 200, 200);
                        // setSprite(6, 6, 1, 180, 200);
                        // setSprite(7, 7, 1, 160, 200);
                        // setSprite(8, 8, 1, 140, 200);
                        // setSprite(9, 9, 1, 280, 220);  // Nova linha
                        // setSprite(10, 10, 1, 260, 220); // Nova linha
                        // setSprite(11, 11, 1, 240, 220); // Nova linha
                        // setSprite(12, 12, 1, 220, 220); // Nova linha
                        // setSprite(13, 13, 1, 200, 220); // Nova linha
                        // setSprite(14, 14, 1, 180, 220); // Nova linha
                        // setSprite(15, 15, 1, 160, 220); // Nova linha
                        // setSprite(16, 16, 1, 140, 220); // Nova linha
                        // setSprite(17, 17, 1, 280, 240); // Nova linha
                        // setSprite(18, 18, 1, 260, 240); // Nova linha
                        // setSprite(19, 19, 1, 240, 240); // Nova linha
                        // setSprite(20, 20, 1, 220, 240); // Nova linha
                        // setSprite(21, 21, 1, 200, 240); // Nova linha
                        // setSprite(22, 22, 1, 180, 240); // Nova linha
                        // setSprite(23, 23, 1, 160, 240); // Nova linha
                        // setSprite(24, 24, 1, 140, 240); // Nova linha
                        setSprite(5, 5, 1, 200, 260); // Nova linha
                        setSprite(6, 6, 1, 220, 260); // Nova linha
                        setSprite(7, 7, 1, 240, 260); // Nova linha
                        setSprite(8, 8, 1, 260, 260); // Nova linha
                        // setSprite(29, 29, 1, 200, 260); // Nova linha
                        // setSprite(30, 30, 1, 180, 260); // Nova linha
                        // setSprite(31, 31, 1, 160, 260); // Nova linha




                        break;
                    }
                }
                // while(1){ if(isFull() == 0) { setSprite(1, 9, 1, (ball.ballPositionX*8)-4, (ball.ballPositionY*8)-4); break; } }

                // generateBall(ball.ballPositionX, ball.ballPositionY, COLOR_WHITE);
                // Esquerda
                videoBox(10, 1, 11, 58, COLOR_CYAN, BLOCK_SIZE);
                // Baixo
                // videoBox(10, 58, 71, 59, COLOR_CYAN, BLOCK_SIZE);
                // Direita
                videoBox(70, 1, 71, 58, COLOR_CYAN, BLOCK_SIZE);
                // Cima
                // videoBox(10, 1, 70, 2, COLOR_CYAN, BLOCK_SIZE);

                videoBox(barJ1.coordX - BAR_SIZE, barJ1.coordY - BAR_WIDHT, barJ1.coordX + BAR_SIZE, barJ1.coordY + BAR_WIDHT, COLOR_WHITE, BLOCK_SIZE);
                // while(1){ if(isFull() == 0) { setSprite(2, 13, 1, ((barJ1.coordX - BAR_SIZE)*8),(barJ1.coordY - BAR_WIDHT)*8); break; } }
                videoBox(barJ2.coordX - BAR_SIZE, barJ2.coordY - BAR_WIDHT, barJ2.coordX + BAR_SIZE, barJ2.coordY + BAR_WIDHT, COLOR_WHITE, BLOCK_SIZE);
                // while(1){ if(isFull() == 0) { setSprite(3, 13, 1, (barJ2.coordX - BAR_SIZE)*8, (barJ2.coordY - BAR_WIDHT)*8); break; } }
                /*Movimentação dos elementos do jogo*/
                pthread_mutex_lock(&lock);
                velX = axis_x * mg_per_lsb;
                velX = normalizeValue(velX,10);
                pthread_mutex_unlock(&lock);
                pthread_mutex_lock(&lockMouse);
                velXMouse = xMouse;
                velXMouse = normalizeValue(velXMouse, 1);
                pthread_mutex_unlock(&lockMouse);
                moveBar(&barJ1, velX);
                moveBar(&barJ2, velXMouse);
                ballRacketCollision(&ball, &barJ1, &cima, &direita, &movVertical, 0);
                ballRacketCollision(&ball, &barJ2, &cima, &direita, &movVertical, 1);
                ballBorderCollision(&ball, &barJ1, &barJ2, &cima, &direita, &scoreJ1, &scoreJ2);

                if (cima == 1 && movVertical == 0)
                {
                    ball.ballPositionY += 1;
                }
                else if (movVertical == 0)
                {
                    ball.ballPositionY -= 1;
                }

                if (direita == 1 && movVertical == 0)
                {
                    ball.ballPositionX += 1;
                }
                else if (movVertical == 0)
                {
                    ball.ballPositionX -= 1;
                }

                if (movVertical == 1 && cima == 1)
                {
                    ball.ballPositionY += 1;
                }
                else if (movVertical == 1)
                {
                    ball.ballPositionY -= 1;
                }
            }
            else if (stateGame == 2)
            { // Estado de pausa

                videoClear();
                clearSprite();
                currentOption = 0;
                int previousCurrentOption = -1;
                while (stateGame == 2)
                { // Loop enquanto o jogo está em pausa
                    // Chama Fpause com a opção atual
                    if (previousCurrentOption != currentOption)
                    {
                        Fpause(currentOption + 1);
                    }
                    previousCurrentOption = currentOption;

                    // Verifica movimento para cima (botão 1 pressionado)
                    
                
                    if (buttonValue == 14 && buttons == 15)
                    {
                        currentOption = (currentOption - 1 + 3) % 3; // Cicla para cima
                    }
                    // Verifica movimento para baixo (botão 2 pressionado)
                    else if (buttonValue == 13 && buttons == 15)
                    {
                        currentOption = (currentOption + 1) % 3; // Cicla para baixo
                    }
                }
            }
            else if (stateGame == 3)
            {

                printf("Entrei nesse estado mediocre");
                scoreJ1 = 0;
                scoreJ2 = 0;
                resetData(&ball, &barJ1, &barJ2);
            }
            else if (stateGame == 4)
            {
                Fover(flagGameOver);
            }
        }
    }

    return 0;
}

void changeStateExec()
{
    gpuMapping(); // Colocada aqui para fazer com que exista o mapeamento do botão !!!!!!
    while (1)
    {

        buttons = buttonRead();
        if (buttons != 15)
        {
            buttonValue = buttons;
        }

        switch (stateGame)
        {

        case 0:

            if (buttonValue == 14 && buttons == 15)
            {

                stateGame = 1;
            }

            break;

        case 1:

            if (buttonValue == 13 && buttons == 15)
            {

                stateGame = 2;
            }

        case 2:

            if (buttonValue == 11 && buttons == 15 && currentOption == 0)
            {

                stateGame = 3;
            }
            else if (buttonValue == 11 && buttons == 15 && currentOption == 1)
            {

                stateGame = 0;
            }
            else if (buttonValue == 11 && buttons == 15 && currentOption == 2)
            {

                stateGame = 1;
            }

            break;

        case 3:
            usleep(10000);
            stateGame = 1;
            break;

        case 4:
            usleep(10000);
            stateGame = 1;
            break;
        }
    }
}
