#include "prototype.h"

void renderScreen(int mode, int width, int height, const uint32_t *bitmap) {
    Color cor;
    if (1){
        for (int i = 0; i < height; i++) {
            for (int j = 0; j < width; j++) {
                int index = width * height + i * width + j;
                switch (bitmap[index]) {
                    case 0xff000000: // Preto virou branco
                        setBackgroundBlock(i, j, 0, 0, 0);
                        break;
                    case 0xffffffff: 
                        setBackgroundBlock(i, j, 7, 7, 7);
                        break;
                    case 0xff0000ff: // Vermelho
                        setBackgroundBlock(i, j, 7, 0, 0);
                        break;
                    case 0xffff0000: // Azul
                        setBackgroundBlock(i, j, 0, 0, 7);
                        break;
                    case 0xffffff00: // Ciano
                        setBackgroundBlock(i, j, 0, 7, 7);
                        break;
                    case 0xffff00ff: // Magenta
                        setBackgroundBlock(i, j, 7, 0, 7);
                        break;
                    case 0xff00ffff: // Amarelo
                        setBackgroundBlock(i, j, 7, 7, 0);
                        break;
                    case 0xff00ff00: // Verde
                        setBackgroundBlock(i, j, 0, 7, 0);
                        break;
                    case 0xffbf8146: //areia molhada
                        cor = convertHexToRgb(0xffbf8146);
                        setBackgroundBlock(i, j, 4, 2, 1);
                    case 0xfff08b2c:
                        cor = convertHexToRgb(0xfff08b2c);
                        setBackgroundBlock(i, j, 7,2,0);
                    case 0xffa98462:
                        cor = convertHexToRgb(0xffa98462);
                        setBackgroundBlock(i, j, 3,2,1);
                    case 0xff007700:
                        cor = convertHexToRgb(0xff007700);
                        setBackgroundBlock(i, j, 0,2,0);
                    case 0xffb7b6b6:
                        cor = convertHexToRgb(0xffb7b6b6);
                        setBackgroundBlock(i, j, 4,4,4);
                    case 0xff5a5a5a:
                        cor = convertHexToRgb(0xff5a5a5a);
                        setBackgroundBlock(i, j, 1,1,1);
                    case 0xffd39107:
                        cor = convertHexToRgb(0xffd39107);
                        setBackgroundBlock(i, j, 5,2,0);
                    case 0xffeae770:
                        cor = convertHexToRgb(0xffeae770);
                        setBackgroundBlock(i, j, 6,6,2);
                    case 0xffd46c27:
                        cor = convertHexToRgb(0xffd46c27);
                        setBackgroundBlock(i, j, 5,1,0);
                    case 0xff87481e:
                        cor = convertHexToRgb(0xff87481e);
                        setBackgroundBlock(i, j, 2,1,0);
                    case 0xff27b015:
                        cor = convertHexToRgb(0xff27b015);
                        setBackgroundBlock(i, j, 0,3,0);
                    default:
                        break;
                }
            }
        }
    
    }
    else {
        for (int i = 0; i < height; i++) {
            for (int j = 0; j < width; j++) {
                int index = width * height + i * width + j;
                switch (bitmap[index]) {
                    case 0xff000000: // Preto virou branco
                        setBackgroundBlock(i, j, 0, 0, 0);
                        break;
                    case 0xffffffff: 
                        setBackgroundBlock(i, j, 0, 0, 0);
                        break;
                    case 0xff0000ff: // Vermelho
                        setBackgroundBlock(i, j, 0, 0, 0);
                        break;
                    case 0xffff0000: // Azul
                        setBackgroundBlock(i, j, 0, 0, 0);
                        break;
                    case 0xffffff00: // Ciano
                        setBackgroundBlock(i, j, 0, 0, 0);
                        break;
                    case 0xffff00ff: // Magenta
                        setBackgroundBlock(i, j, 0, 0, 0);
                        break;
                    case 0xff00ffff: // Amarelo
                        setBackgroundBlock(i, j, 0, 0, 0);
                        break;
                    case 0xff00ff00: // Verde
                        setBackgroundBlock(i, j, 0, 0, 0);
                        break;
                    case 0xff4681bf: //areia molhada
                        cor = convertHexToRgb(0xff4681bf);
                        setBackgroundBlock(i, j, 0, 0, 0);
                    case 0xff2c8bf0:
                        cor = convertHexToRgb(0xff2c8bf0);
                        setBackgroundBlock(i, j, 7,2,0);
                    case 0xff6284a9:
                        cor = convertHexToRgb(0xff6284a9);
                        setBackgroundBlock(i, j, 0, 0, 0);
                    case 0xff007700:
                        cor = convertHexToRgb(0xff007700);
                        setBackgroundBlock(i, j, 0,0,0);
                    case 0xffb6b6b7:
                        cor = convertHexToRgb(0xffb6b6b7);
                        setBackgroundBlock(i, j, 0,0,0);
                    case 0xff5a5a5a:
                        cor = convertHexToRgb(0xff5a5a5a);
                        setBackgroundBlock(i, j, 0,0,0);
                    case 0xff0791d3:
                        cor = convertHexToRgb(0xff0791d3);
                        setBackgroundBlock(i, j, 0,0,0);
                    case 0xff70e7ea:
                        cor = convertHexToRgb(0xff70e7ea);
                        setBackgroundBlock(i, j, 0,0,0);
                    case 0xff276cd4:
                        cor = convertHexToRgb(0xff276cd4);
                        setBackgroundBlock(i, j, 0,0,0);
                    case 0xff1e4887:
                        cor = convertHexToRgb(0xff1e4887);
                        setBackgroundBlock(i, j, 0,0,0);
                    case 0xff15b02:
                        cor = convertHexToRgb(0xff15b02);
                        setBackgroundBlock(i, j, 0,0,0);
                    default:
                        break;
                    }
                }
            }
        }
}

void Fhome(){
   for (int i=0; i<HOME_FRAME; i++){
        renderScreen(1, HOME_WIDTH, HOME_HEIGHT, *home);
        usleep(100000);
        renderScreen(0, HOME_WIDTH, HOME_HEIGHT, *home);
    }
}

void Fpause(){
    for (int i=0; i<PAUSE_FRAME; i++){
        renderScreen(1, PAUSE_WIDTH, PAUSE_HEIGHT, *Bpause);
        renderScreen(0, PAUSE_WIDTH, PAUSE_HEIGHT, *Bpause);
    }
}

void Fover(int player){
    if(player == 1){
        for (int i=0; i<2; i++){
        renderScreen(1, OVER_WIDTH, OVER_HEIGHT, *over);
        renderScreen(0, OVER_WIDTH, OVER_HEIGHT, *over);
        }
    } 
    else {
        renderScreen(1, OVER_WIDTH, OVER_HEIGHT, *over);
        renderScreen(0, OVER_WIDTH, OVER_HEIGHT, *over);
        renderScreen(1, OVER_WIDTH, OVER_HEIGHT, *over);;
        renderScreen(0, OVER_WIDTH, OVER_HEIGHT, *over);
    }
}
