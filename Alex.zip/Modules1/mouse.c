
#include "linux/input.h"
#include <fcntl.h> // Para open()
#include <unistd.h> // Para read()
#include <stdio.h> // Para printf()
#include "prototype.h"

int fd_event;
int mouse_x_axis = 0; // Armazena o valor do eixo X


void linux_event_file(void) {
    fd_event = open("/dev/input/event0", O_RDONLY); // Verificar o endereço correto do dispositivo
    if (fd_event == -1)
        printf("Falha ao acessar os dispositivos de entrada!\n");
}

// Lendo o evento do Linux que armazena o valor do eixo X do mouse:
void read_mouse_axis(void) {
    struct input_event event; // Criando uma variável do tipo "input_event".
    
    // Lendo o evento e armazenando o seu valor:
    ssize_t n = read(fd_event, &event, sizeof(struct input_event));
    if (n == sizeof(struct input_event)) {
        if (event.type == EV_REL && event.code == REL_X) {
            mouse_x_axis = event.value; // Atualizando o valor do eixo X
        }
    }
}

void* check_player2_input(void* arg) {
    while (1) {
        pthread_mutex_lock(&lockMouse);
        read_mouse_axis(); // Atualizando o valor do eixo X do mouse.

        // Exemplo de uso do eixo X para movimentação:
        int player2_bg_col = sp_col_to_bg_col(xMouse +mouse_x_axis);

        // Controle baseado nos limites horizontais do jogador 2
        if (player2_bg_col >= 10 && player2_bg_col < 90) { // Ajuste conforme necessário
            xMouse += mouse_x_axis; // Atualiza posição com base no movimento no eixo X
        }
        pthread_mutex_unlock(&lockMouse);
    }
    return NULL;
}
